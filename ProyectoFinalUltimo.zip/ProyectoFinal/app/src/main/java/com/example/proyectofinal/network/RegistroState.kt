package com.example.proyectofinal.network


data class RegistroState(
    val listaregistros: List<Registro> = emptyList()
)
