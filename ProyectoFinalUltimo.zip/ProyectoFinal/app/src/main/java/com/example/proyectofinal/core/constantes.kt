package com.example.proyectofinal.core

class constantes {
    companion object{
        //Room
        const val REGISTRO_TABLE = "registro_table"
        // Screens
        const val REGISTRO_SCREEN = "registro"
        const val UPDATE_REGISTRO_SCREEN = "Update registro"
        // Arguments
        const val REGISTRO_ID = "registroId"
        // Actions
        const val ADD_REGISTRO = "Agregar registro"
        const val DELETE_REISTRO = "Borrar un registro"

        // Buttons
        const val ADD = "Agregar"
        const val DISMISS ="Cancelar."
        const val UPDATE = "Modificar"
        // Placeholders
        const val ANIMAL = ""
        const val RAZA = ""
        const val NO_VALUE =""

    }
}