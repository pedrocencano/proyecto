package com.example.proyectofinal.network

import androidx.room.ColumnInfo
import androidx. room. Entity
import androidx.room.PrimaryKey
import com.example.proyectofinal.core.constantes.Companion.REGISTRO_TABLE

@Entity(tableName = REGISTRO_TABLE)
data class Registro(
    @PrimaryKey(autoGenerate = true)
    val id : Int = 0,
    @ColumnInfo("nombre")
    val nombrePro : String,
    @ColumnInfo("objetivo")
    val objetivo: String,
    @ColumnInfo("descripcion")
    val descripcion: String,
    @ColumnInfo("impacto")
    val impacto: String,
    @ColumnInfo("lugar")
    val Lugar: String,
    @ColumnInfo("nombreP")
    val nombrePer: String,
    @ColumnInfo("cantE")
    val cantEst: String,
    @ColumnInfo("numCont")
    val nombreNCont: String,
    @ColumnInfo("carreras")
    val carreras: String,
    @ColumnInfo("tiempo")
    val tiempo: String,
    @ColumnInfo("tipo")
    val tipo: String,
    @ColumnInfo("linea")
    val linea: String,
    @ColumnInfo("beneficios")
    val beneficios: String,
    @ColumnInfo("referencias")
    val ref: String
)
