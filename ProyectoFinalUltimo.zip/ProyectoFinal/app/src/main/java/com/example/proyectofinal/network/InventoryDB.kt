package com.example.proyectofinal.network

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [Registro::class], version = 1, exportSchema = false)
abstract class InventoryDB : RoomDatabase(){
    abstract fun RegistroDAO(): RegistroDAO
    companion object{
        @Volatile
        private var Instance: InventoryDB? = null
        fun getDatabase(context: Context): InventoryDB {
            return Instance ?: synchronized(this) {
                Room.databaseBuilder(context, InventoryDB::class.java, "Registro_database")
                    .build()
                    .also { Instance = it }
            }
        }
    }
}