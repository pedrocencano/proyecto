package com.example.proyectofinal.model

import android.annotation.SuppressLint
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavController
import com.example.proyectofinal.network.OfflineRegistroRepositorio
import com.example.proyectofinal.network.RegistroDAO
import com.example.proyectofinal.network.RegistroRpositorio
import com.example.proyectofinal.network.registroViewModel

class VerProyectos {

}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun verProyectos(
    viewModel: registroViewModel,
    navController:NavController
)
{
    Scaffold (

        topBar = { topBar() },
        content = {
            VerProyecto(it, navController, viewModel)
        }
    )
}
@Composable
fun VerProyecto(
    it: PaddingValues,
    navController: NavController,
    viewModel: registroViewModel
){
    val registro =  viewModel.state
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.White)
    ) {


        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF4FA598))
                .padding(16.dp)
        ) {
            Column {
                Text(
                    text = "Banco de proyectos 2024 - 1",
                    color = Color.White,
                    fontSize = 25.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                Text(
                    text = "Formulario para registrar resuesta preeliminares de proyectos de desarrollo tecnológico, investigacion y/o vinculación del departamento de sistemas y computación",
                    color = Color.White,
                    fontSize = 10.sp
                )
            }
        }

        LazyColumn(
            modifier = Modifier.padding(it)
        ) {

            item (registro.listaregistros){
                Column {
                    Text(text = it.nombrePro)
                    Text(text = "")
                }

                Button(onClick = { navController.popBackStack() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                        .background(Color(0xFF4FA598))
                ) {
                    Text(text = "Regresar")
                }
            }
        }
    }
}