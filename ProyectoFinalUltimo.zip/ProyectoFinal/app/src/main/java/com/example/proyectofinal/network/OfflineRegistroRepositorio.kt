package com.example.proyectofinal.network


import kotlinx.coroutines.flow.Flow

class OfflineRegistroRepositorio(private val RegistroDAO: RegistroDAO) : RegistroRpositorio {
    override fun getRegistros(): Flow<List<Registro>> = RegistroDAO.getRegistros()

    override fun getRegistro(id: Int): Flow<Registro?> = RegistroDAO.getRegistro(id)

    override suspend fun InsertRegistro(registro: Registro) = RegistroDAO.InsertRegistro(registro)

    override suspend fun deleteRegistro(registro: Registro) = RegistroDAO.delete(registro)

    override suspend fun updateRegistro(registro: Registro) = RegistroDAO.update(registro)
}