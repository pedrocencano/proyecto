package com.example.proyectofinal.network

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class registroViewModel (private val dao: RegistroDAO):ViewModel() {

    var state by mutableStateOf(RegistroState())
        private set

    init{
        viewModelScope.launch{
            dao.getRegistros().collectLatest {
                state = state.copy(
                    listaregistros = it
                )
            }
        }
    }

    suspend fun Agregar(registro: Registro){
        dao.InsertRegistro(registro = registro)
    }

    suspend fun editar(registro: Registro){
        dao.InsertRegistro(registro = registro)
    }

    suspend fun eliminar(registro: Registro){
        dao.delete(registro = registro)
    }

    suspend fun actualizar(registro: Registro){
        dao.update(registro = registro)
    }
}