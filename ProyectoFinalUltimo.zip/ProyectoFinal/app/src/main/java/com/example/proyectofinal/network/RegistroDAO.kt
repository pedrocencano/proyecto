package com.example.proyectofinal.network

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.OnConflictStrategy.Companion.IGNORE
import androidx.room.Query
import androidx.room.Update
import com.example.proyectofinal.core.constantes.Companion.REGISTRO_TABLE
import kotlinx.coroutines.flow.Flow

@Dao
interface  RegistroDAO {
    @Query("SELECT * FROM $REGISTRO_TABLE")
    fun getRegistros (): Flow<List<Registro>>

    @Query("SELECT * FROM $REGISTRO_TABLE WHERE id = :id")
    fun getRegistro (id: Int): Flow<Registro>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun InsertRegistro (registro: Registro)

    //UPDATE
    @Update
    suspend fun update(registro: Registro)

    //DELETE
    @Delete
    suspend fun delete(registro: Registro)

}