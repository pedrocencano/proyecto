package com.example.proyectofinal.navegación

sealed class Destinations(
    val route: String
){
    object inicio: Destinations("inicio")
    object registrar: Destinations("registrar")
    object ver: Destinations("ver")

}
