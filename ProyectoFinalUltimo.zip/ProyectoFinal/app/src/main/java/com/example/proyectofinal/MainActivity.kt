package com.example.proyectofinal


import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.proyectofinal.model.segundaPrueba
import com.example.proyectofinal.navegación.navegationHost
import com.example.proyectofinal.network.InventoryDB
import com.example.proyectofinal.network.registroViewModel
import com.example.proyectofinal.ui.theme.ProyectoFinalTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ProyectoFinalTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val database = Room.databaseBuilder(this, InventoryDB::class.java, "db_registro").build()
                    val dao = database.RegistroDAO()

                    val viewModel = registroViewModel(dao)

                    navegationHost(viewModel)
                }
            }
        }
    }
}

@Composable
fun PrimeraPantalla() {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Cyan)

    ) {
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(30.dp)
                    .background(color = Color.Blue)
            )
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(30.dp)
                    .background(color = Color.Blue)

            ) {
                Text(text = "Stack:", color = Color.White)
                Text(text = "Java", color = Color.White)
                Text(text = "KOTLIN", color = Color.White)
                Text(text = "SUSCRIBET", color = Color.White)

            }

        }

    }
}

@Preview
@Composable
fun GreetingPreview() {
    ProyectoFinalTheme {
        //navegationHost()
    }
}
