package com.example.proyectofinal.navegación

import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.proyectofinal.model.MainScreen
import com.example.proyectofinal.model.VerProyecto
import com.example.proyectofinal.model.VerProyectos
import com.example.proyectofinal.model.segundaPrueba
import com.example.proyectofinal.model.verProyectos
import com.example.proyectofinal.network.registroViewModel


@Composable
fun navegationHost(viewModel: registroViewModel){
    val navController = rememberNavController()
    
    NavHost(navController = navController, startDestination = Destinations.inicio.route){
        composable("inicio"){
            MainScreen(
                navController = navController,
                viewModel = viewModel
            )
        }
        composable("registrar"){
            segundaPrueba(
                navController = navController,
                viewModel = viewModel
            )
        }

        composable("ver"){
            verProyectos(
                navController = navController,
                viewModel = viewModel
            )
        }

    }
}