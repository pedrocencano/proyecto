package com.example.proyectofinal.repositorio

import android.content.Context
import com.example.proyectofinal.network.InventoryDB
import com.example.proyectofinal.network.OfflineRegistroRepositorio
import com.example.proyectofinal.network.RegistroRpositorio

interface AppContainer {
    val RegistroRpositorio: RegistroRpositorio
}

class AppDataContainer(private val context: Context) : AppContainer {

    override val RegistroRpositorio: RegistroRpositorio by lazy {
        OfflineRegistroRepositorio(InventoryDB.getDatabase(context).RegistroDAO())
    }
}