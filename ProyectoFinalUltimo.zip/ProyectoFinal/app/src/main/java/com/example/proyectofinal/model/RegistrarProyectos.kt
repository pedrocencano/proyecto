package com.example.proyectofinal.model

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonColors
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.contentColorFor
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.rememberNavController
import com.example.proyectofinal.navegación.navegationHost
import com.example.proyectofinal.network.Registro
import com.example.proyectofinal.network.registroViewModel


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun segundaPrueba(
    viewModel: registroViewModel,
    navController:NavController
)
{
    Scaffold (

        topBar = { topBar() },
        content = { MyFormulario(it, navController,viewModel)}

    )
}

@Composable
fun topBar(){
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF4FA598))
            .padding(16.dp)
    ) {
        Column {
            Text(
                text = "Banco de proyectos 2024 - 1",
                color = Color.White,
                fontSize = 25.sp,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            Text(
                text = "Formulario para registrar resuesta preeliminares de proyectos de desarrollo tecnológico, investigacion y/o vinculación del departamento de sistemas y computación",
                color = Color.White,
                fontSize = 10.sp
            )
        }
    }

}
@Composable
fun MyFormulario(it:PaddingValues,navController: NavController,viewModel: registroViewModel){

    var nombre by rememberSaveable{ mutableStateOf("") }
    var objetivo by rememberSaveable{ mutableStateOf("") }
    var descrip by rememberSaveable{ mutableStateOf("") }
    var impacto by rememberSaveable{ mutableStateOf("") }
    var lugar by rememberSaveable{ mutableStateOf("") }
    var nombrePer by rememberSaveable{ mutableStateOf("") }
    var cantEst by rememberSaveable{ mutableStateOf("") }
    var nombreNCont by rememberSaveable{ mutableStateOf("") }
    var carreras by rememberSaveable{ mutableStateOf("") }
    var tiempo by rememberSaveable{ mutableStateOf("") }
    var tipo by rememberSaveable{ mutableStateOf("") }
    var linea by rememberSaveable{ mutableStateOf("") }
    var beneficios by rememberSaveable{ mutableStateOf("") }
    var referencias by rememberSaveable{ mutableStateOf("") }
    Column(
        modifier = Modifier
            .padding(it)
            .fillMaxWidth()
            .background(Color.White)
    ) {


        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            item{
                Spacer(modifier = Modifier
                    .fillMaxWidth()
                    .padding(60.dp)
                )
            }
            item {
                nombre("Manuel")
                Row {
                    Text(
                        text = "* ",
                        color = Color.Red,
                        fontSize = 8.sp
                    )
                    Text(
                        text = "Obligatorio",
                        color = Color.Gray,
                        fontSize = 8.sp
                    )
                }
                Column(
                    modifier = Modifier
                        .padding(vertical = 8.dp)
                ) {

                    Text(
                        text = "1.- Nombre del proyecto",
                        color = Color.Black,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Default,
                        fontWeight = FontWeight.Bold
                    )

                    BasicTextField(
                        value = nombre,
                        onValueChange = { nombre = it },
                        textStyle = LocalTextStyle.current.copy(fontSize = 16.sp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp)
                            .border(1.dp, Color.Gray, shape = MaterialTheme.shapes.small)
                            .padding(8.dp)
                    )
                }
                Column(
                    modifier = Modifier
                        .padding(vertical = 8.dp)
                ) {

                    Text(
                        text = "2.- Objetivo del proyecto",
                        color = Color.Black,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Default,
                        fontWeight = FontWeight.Bold
                    )
                    BasicTextField(
                        value = objetivo,
                        onValueChange = { objetivo = it },
                        textStyle = LocalTextStyle.current.copy(fontSize = 16.sp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp)
                            .border(1.dp, Color.Gray, shape = MaterialTheme.shapes.small)
                            .padding(27.dp)
                    )
                }
                Column(
                    modifier = Modifier
                        .padding(vertical = 8.dp)
                ) {
                    Text(
                        text = "3.- Brebe descripción del proyecto",
                        color = Color.Black,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Default,
                        fontWeight = FontWeight.Bold
                    )
                    BasicTextField(
                        value = descrip,
                        onValueChange = { descrip = it },
                        textStyle = LocalTextStyle.current.copy(fontSize = 16.sp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp)
                            .border(1.dp, Color.Gray, shape = MaterialTheme.shapes.small)
                            .padding(27.dp)
                    )
                }
                Column(
                    modifier = Modifier
                        .padding(vertical = 8.dp)
                ) {
                    Text(
                        text = "4.- Impacto del proyexto",
                        color = Color.Black,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Default,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Establecer la importancias y aporte de la investigación propuesta en función de la generación de conocimientos, desarrollo tecnológico, innovación y la solución de problemáticas locales, nacionales e internacionales",
                        color = Color.Gray,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Default,
                        fontWeight = FontWeight.Bold
                    )

                    BasicTextField(
                        value = impacto,
                        onValueChange = { impacto = it },
                        textStyle = LocalTextStyle.current.copy(fontSize = 16.sp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp)
                            .border(1.dp, Color.Gray, shape = MaterialTheme.shapes.medium)
                            .padding(27.dp)
                    )
                }

                Column(
                    modifier = Modifier
                        .padding(vertical = 8.dp)
                ) {
                    Text(
                        text = "5.- Lugar donde se va a desarrollar",
                        color = Color.Black,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Default,
                        fontWeight = FontWeight.Bold
                    )

                    BasicTextField(
                        value = lugar,
                        onValueChange = {lugar = it },
                        textStyle = LocalTextStyle.current.copy(fontSize = 16.sp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp)
                            .border(1.dp, Color.Gray, shape = MaterialTheme.shapes.small)
                            .padding(8.dp)
                    )
                }

                Column(
                    modifier = Modifier
                        .padding(vertical = 8.dp)
                ) {

                    Text(
                        text = "6.- Nombre de la persona que realiza la propuesta para banco de proyectos. En caso de ser una propuesta propia del alumno incluir número de control.\n",
                        color = Color.Black,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Default,
                        fontWeight = FontWeight.Bold
                    )

                    BasicTextField(
                        value = nombrePer,
                        onValueChange = { nombrePer = it },
                        textStyle = LocalTextStyle.current.copy(fontSize = 16.sp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp)
                            .border(1.dp, Color.Gray, shape = MaterialTheme.shapes.small)
                            .padding(8.dp)
                    )
                }
                Column(
                    modifier = Modifier
                        .padding(vertical = 8.dp)
                ) {
                    Text(
                        text = "7.- Cantidad de estudiantes requeridos",
                        color = Color.Black,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Default,
                        fontWeight = FontWeight.Bold
                    )


                    BasicTextField(
                        value = cantEst,
                        onValueChange = { cantEst = it },
                        textStyle = LocalTextStyle.current.copy(fontSize = 16.sp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp)
                            .border(1.dp, Color.Gray, shape = MaterialTheme.shapes.small)
                            .padding(8.dp)
                    )
                }
                Column(
                    modifier = Modifier
                        .padding(vertical = 8.dp)
                ) {
                    Text(
                        text = "8.- Nombre y número de control de los alumnos integrados al proyecto en caso de tener asignados\n",
                        color = Color.Black,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Default,
                        fontWeight = FontWeight.Bold
                    )

                    BasicTextField(
                        value = nombreNCont,
                        onValueChange = { nombreNCont = it },
                        textStyle = LocalTextStyle.current.copy(fontSize = 16.sp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp)
                            .border(1.dp, Color.Gray, shape = MaterialTheme.shapes.medium)
                            .padding(27.dp)
                    )
                }
                Column(
                    modifier = Modifier
                        .padding(vertical = 8.dp)
                ) {
                    // Pregunta en color negro con fuente Arial
                    Text(
                        text = "9.- Carrera requerida de los estudiantes",
                        color = Color.Black,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Default,
                        fontWeight = FontWeight.Bold
                    )
                    var respuestasSeleccionadas by remember { mutableStateOf(emptyList<String>()) }

                    val opciones: List<String>
                    opciones = listOf("Ingenieria en tecnologias de la informacion y comunicaciones","Ingeniería en sistemas computacionales","Interdiciplinario")

                    // Casillas de verificación
                    opciones.forEach { opcion ->
                        Row(
                            modifier = Modifier
                                .padding(vertical = 4.dp)
                        ) {
                            Checkbox(
                                checked = respuestasSeleccionadas.contains(opcion),
                                onCheckedChange = {
                                    respuestasSeleccionadas =
                                        if (respuestasSeleccionadas.contains(opcion)) {
                                            respuestasSeleccionadas - opcion
                                        } else {
                                            respuestasSeleccionadas + opcion
                                        }
                                },
                                modifier = Modifier.padding(end = 8.dp)
                            )
                            Text(text = opcion)
                        }

                        carreras = respuestasSeleccionadas.joinToString(", ")
                    }
                }
                Column(
                    modifier = Modifier
                        .padding(vertical = 8.dp)
                ) {
                    Text(
                        text = "10.- Tiempo estimado en meses",
                        color = Color.Black,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Default,
                        fontWeight = FontWeight.Bold
                    )


                    BasicTextField(
                        value = tiempo,
                        onValueChange = { tiempo = it },
                        textStyle = LocalTextStyle.current.copy(fontSize = 16.sp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp)
                            .border(1.dp, Color.Gray, shape = MaterialTheme.shapes.small)
                            .padding(8.dp)
                    )
                }

                Column(
                    modifier = Modifier
                        .padding(vertical = 8.dp)
                ) {
                    // Pregunta en color negro con fuente Arial
                    Text(
                        text = "11.- Tipo de propuesta para integrarse al banco de:",
                        color = Color.Black,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Default,
                        fontWeight = FontWeight.Bold
                    )
                    var respuestasSeleccionadas by remember { mutableStateOf(emptyList<String>()) }

                    val opciones: List<String>
                    opciones = listOf("Protocolo de investigación","Residencias Profecional")

                    // Casillas de verificación
                    opciones.forEach { opcion ->
                        Row(
                            modifier = Modifier
                                .padding(vertical = 4.dp)
                        ) {
                            Checkbox(
                                checked = respuestasSeleccionadas.contains(opcion),
                                onCheckedChange = {
                                    respuestasSeleccionadas =
                                        if (respuestasSeleccionadas.contains(opcion)) {
                                            respuestasSeleccionadas - opcion
                                        } else {
                                            respuestasSeleccionadas + opcion
                                        }
                                },
                                modifier = Modifier.padding(end = 8.dp)
                            )
                            Text(text = opcion)
                        }

                        tipo = respuestasSeleccionadas.joinToString(", ")
                    }
                }


                Column(
                    modifier = Modifier
                        .padding(vertical = 8.dp)
                ) {
                    var respuestaSeleccionada by remember { mutableStateOf("") }
                    val opciones: List<String>
                    opciones = listOf("Sistemas de computo para la autonomía de las cosas(LGAC-2017-CHET-ITIC-17) ITIC","Sistemas, bases de datos y plataformas coputacionales (LGAC-2017-CHET-ISCO-14) ISIC")

                    Text(
                        text ="12.- Linea de investigación a la que beneficia",
                        color = Color.Black,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Default,
                        fontWeight = FontWeight.Bold
                    )

                    // Opciones de respuesta
                    opciones.forEach { linea ->
                        Row(
                            modifier = Modifier
                                .padding(vertical = 4.dp)
                        ) {
                            RadioButton(
                                selected = respuestaSeleccionada == linea,
                                onClick = { respuestaSeleccionada = linea },
                                modifier = Modifier.padding(end = 8.dp)
                            )
                            Text(text = linea)
                        }
                    }

                }

                Column(
                    modifier = Modifier
                        .padding(vertical = 8.dp)
                ) {
                    Text(
                        text = "13.- ¿Como beneficia a los estudiantes articipantes",
                        color = Color.Black,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Default,
                        fontWeight = FontWeight.Bold
                    )
                    var respuestasSeleccionadas by remember { mutableStateOf(emptyList<String>()) }

                    val opciones: List<String>
                    opciones = listOf("Servicio Social","Residencia profecional","Titulación","Creditos Complementarios","Beca", "Participaciones en congresos de innovación y/o investigación")

                    opciones.forEach { opcion ->
                        Row(
                            modifier = Modifier
                                .padding(vertical = 4.dp)
                        ) {
                            Checkbox(
                                checked = respuestasSeleccionadas.contains(opcion),
                                onCheckedChange = {
                                    respuestasSeleccionadas =
                                        if (respuestasSeleccionadas.contains(opcion)) {
                                            respuestasSeleccionadas - opcion
                                        } else {
                                            respuestasSeleccionadas + opcion
                                        }
                                },
                                modifier = Modifier.padding(end = 8.dp)
                            )
                            Text(text = opcion)
                        }

                        beneficios = respuestasSeleccionadas.joinToString(", ")
                    }
                }
                Column(
                    modifier = Modifier
                        .padding(vertical = 8.dp)
                ) {
                    Text(
                        text = "14.- Referencias",
                        color = Color.Black,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Default,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Incluye las referencias esenciales para enmarcar el contenido de su propuesta",
                        color = Color.Gray,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Default,
                        fontWeight = FontWeight.Bold
                    )

                    BasicTextField(
                        value = referencias,
                        onValueChange = { referencias = it },
                        textStyle = LocalTextStyle.current.copy(fontSize = 16.sp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp)
                            .border(1.dp, Color.Gray, shape = MaterialTheme.shapes.medium)
                            .padding(27.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = {
                        val registro = Registro(nombrePro = nombre, objetivo = objetivo, descripcion = descrip, impacto = impacto,
                            Lugar = lugar, nombrePer = nombrePer, cantEst = cantEst, nombreNCont = nombreNCont, carreras = carreras, tiempo = tiempo, tipo = tipo,
                            linea = linea, beneficios = beneficios, ref = referencias)
                        suspend { viewModel.Agregar(registro) }

                        navController.popBackStack()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                        .background(Color(0xFF4FA598)),

                ) {
                    Text(text = "Guardar Respuesta")
                }
            }
        }
    }
}

@Composable
fun nombre(name: String = "Alumno"){
    Text(text = "Hola $name cuando envie este formulario el propietario verá su nombre y su direccion de correo electrónico",
        modifier = Modifier.padding(10.dp),
        color = Color.Gray,
        fontSize = 9.sp
    )

}
